
package nb.test.gamepackagev1;
import edu.sjcny.gpv1.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import edu.sjcny.gpv1.*;
import java.awt.Image; 


public class NBTestGamePackageV1 extends DrawableAdapter
{   static NBTestGamePackageV1 ge = new NBTestGamePackageV1(); 
    static GameBoard gb = new GameBoard(ge, "Food Frenzy");
    
    static catcher [] catcherdraw = new catcher[1];
    static oranges orangesin[] = new oranges[1];
    public static void main(String[] args) 
    {
          showGameBoard(gb);
           for (int i = 0; i < orangesin.length; i++){
            orangesin[i] = new oranges(10 + i * 50, 50);
    }
           for (int i = 0; i < catcherdraw.length; i++)
        {
            catcherdraw[i] = new catcher(10 , 300);
        }
          
          
            // TODO code application logic here
    }
    public static void moveoranges(){
        int x, y;
        for (int i = 0; i <orangesin.length; i++){

            
            
            y = orangesin[i].getY();
            y = y + orangesin[i].getYSpeed();
            orangesin[i].setY(y);
            
        }
        
    }
    public void draw(Graphics g){
        
          for (int i = 0; i < orangesin.length; i++){
            orangesin[i].show(g);
        }
        for (int i = 0; i < catcherdraw.length; i++)
        {
            if (catcherdraw[i].getVisible() == true)
                {
                catcherdraw[i].show(g);
                }
        }
          for (int i = 0; i < catcherdraw.length; i ++)
        {
            if(catcherdraw[i].getVisible() == false )
            {
            
                gb.setBackground(Color.BLACK);
                g.setColor(Color.WHITE);
                g.drawString("GAME OVER", 200 , 200);
            }
        }
        
        
        
        
        
    }
    
    //3 timers
    //they start when player hits START, and stop when player hits STOP
    //call back methods runs for every tick of the timer

    public void timer1(){
         //default timer1, once every 1 second
        
    }

    public void timer2(){
         //default timer2, once every 1/2 second
   
    }

    public void timer3(){
         //default timer3, once every 1/4 second
        moveoranges();
    }

    public void setTimerInterval(int timerNumber, int interal){
        //use to change default interval timer values
    }
    public void startTimer(int timerNumber){
        //used to start a timer
    }
    //4 buttons

    
        public void keyStruck(char key)
    {
       int newX , newY;
       
       for (int i = 0; i < 1; i++)
       {
           switch (key)
           {
               case 'L':
               {
                   newX = catcherdraw[i].getX()-10;
                   catcherdraw[i].setX(newX);
                   break;
               }
               
               case 'R':
               {
                   newX = catcherdraw[i].getX()+10;
                   catcherdraw[i].setX(newX);
                   break;
               }
               
               case 'U':
               {
                   newY = catcherdraw[i].getY()-10;
                   catcherdraw[i].setY(newY);
                   break;
               }
               
               case 'D':
               {
                   newY = catcherdraw[i].getY()+10;
                   catcherdraw[i].setY(newY);
                   break;
               }
           
           }
           
           
               
       }
    }
    
    
  

    public void mouseClicked(int x, int y, int buttonPressed){
        //x, y and game board cordinates
        //buttonPressed contains 1 for left, and 3 for right mouse button
        
    }
    
}
