/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nb.test.gamepackagev1;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author hamza
 */
public class catcher {
    
    private int x ;
    private int y ;
    private int width = 30;
    private int height = 40;
    private boolean visible = true;
    
    public catcher(){}
    
    public catcher(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    public void show(Graphics g)
    {
        g.setColor(Color.YELLOW);
        g.fillRect(x + 20, y + 100, 80, 50);
        g.setColor(Color.WHITE);
        g.fillRect(x + 33, y + 93, 5, 10);
        g.setColor(Color.WHITE);
        g.fillRect(x + 83, y + 93, 5, 10);
        
    }
    
    public int getX()
    {
        return x;
    }
    
    public void setX(int newX)
    {
        x = newX;
    }
    
    public int getY()
    {
        return y;
    }
    
    public void setY(int newY)
    {
        y = newY;
    }
    
    public boolean getVisible()
    {
        return visible;
    }
    
    public void setVisible(boolean newVisible)
    {
        visible = newVisible;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getHeight()
    {
        return height;
    }
    
}
