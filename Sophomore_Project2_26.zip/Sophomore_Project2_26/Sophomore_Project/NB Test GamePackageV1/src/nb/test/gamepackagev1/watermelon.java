
package nb.test.gamepackagev1;

import java.awt.Color;
import java.awt.Graphics;
//good food
/**
 *
 * @author Spenser
 */
public class watermelon {
    
  int x;
    int y;
     int xSpeed = 8;
     int ySpeed = 12;
    int height = 50;
    int width = 50;

 public watermelon(int x, int y)  
    { 
      this.x = x;  
      this.y = y;
    }   
    public void show(Graphics g)
    {
       
      
     
    }
    public int getX()
    { int x2 = x;
        return x2;
    }

    public void setX(int newX)
    { x = newX;
    }
        public int getY()
    { int y2 = y;
        return y2;
    }
   public void setY(int newY)
    { y = newY;
    }

    
    public int getXSpeed()
    {return xSpeed;
    
    }
    public int getYSpeed()
    {return ySpeed;
    }
    
    public void setYSpeed(int s){
    ySpeed = s;
    
    }
    public void setXSpeed(int s){
    xSpeed = s;
    }
      public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}
