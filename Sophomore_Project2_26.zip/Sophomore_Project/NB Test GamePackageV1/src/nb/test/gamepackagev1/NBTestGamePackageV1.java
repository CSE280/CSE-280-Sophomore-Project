
package nb.test.gamepackagev1;
import edu.sjcny.gpv1.*;

import java.awt.*;

public class NBTestGamePackageV1 extends DrawableAdapter
{   static NBTestGamePackageV1 ge = new NBTestGamePackageV1(); 
    static GameBoard gb = new GameBoard(ge, "Snowman by Bill McAllister");
    public static void main(String[] args) 
    {
          showGameBoard(gb);
            // TODO code application logic here
    }
    
    public void draw(Graphics G){
        //runs when gameboard is re-drawn
    }
    
    //3 timers
    //they start when player hits START, and stop when player hits STOP
    //call back methods runs for every tick of the timer

    public void timer1(){
         //default timer1, once every 1 second
      
    }

    public void timer2(){
         //default timer2, once every 1/2 second
   
    }

    public void timer3(){
         //default timer3, once every 1/4 second
        
    }

    public void setTimerInterval(int timerNumber, int interal){
        //use to change default interval timer values
    }
    public void startTimer(int timerNumber){
        //used to start a timer
    }
    //4 buttons

    public void leftButton(){
        
    }
    public void rightButton(){
        
    }
    public void upButton(){
        
    }
    public void downButton(){
        
    }



    public void keyStruck(char key){
     //key contains the uppercase of the key struck       
       
    }

    public void mouseClicked(int x, int y, int buttonPressed){
        //x, y and game board cordinates
        //buttonPressed contains 1 for left, and 3 for right mouse button
        
    }
    
}
