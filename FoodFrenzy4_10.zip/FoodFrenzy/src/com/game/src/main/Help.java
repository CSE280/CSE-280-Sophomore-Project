package com.game.src.main;
import java.io.*;
import javax.swing.event.*;
import javax.swing.*;
import java.net.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Help {
	
	
	public Rectangle backButton = new Rectangle(Game.WIDTH / 2+ 123, 35, 100, 50);
	 
	
	
	public void render(Graphics g){
		
		Graphics2D g2d = (Graphics2D) g;
		
		Font fnt1 = new Font("arial", Font.BOLD, 30);
		g.setFont(fnt1);
		g.setColor(Color.white);
		
		
		
		Font fnt2 = new Font("arial", Font.BOLD, 15);
		g.drawString("Help",backButton.x + 20, backButton.y + 35);
		g.setFont(fnt2);
		
		
		g.drawRect(110,95,450,380);
                g.drawString("-LEFT ARROW KEY MOVES SPACESHIP TO THE LEFT", 125,120 );
                g.drawString("-RIGHT ARROW KEY MOVES SPACESHIP TO THE RIGHT", 125,140 );
                g.drawString("-UP ARROW KEY MOVES SPACESHIP UP", 125,160 );
                g.drawString("-DOWN ARROW KEY MOVES SPACESHIP DOWN", 125,180 );
		g.drawString("-SPACE BAR SHOOTS FRUIT", 125,200 );
                g.drawString("-Shooting any meats such as chicken will give more,",160,230);
                g.drawString("points because of the amount of protein that it carries.",160,250);
                g.drawString("-Shooting any fruits will give you 1 point because,",160,270);
		g.drawString("of the natural sugars that are inside, but eating to much",160,290);
                g.drawString("sugar natural of not is not good for you.",160,310);
                g.drawString("-Junk foods are considered anything that is not a",160,330);
                g.drawString("fruit/vegetable or some type of meat,",160,350);
                g.drawString("these are worth -3 points because they set your life.", 160, 370);
                g.drawString("-Vegetables are worth 2 points because, ",160,390);
                g.drawString("they are good for you and have lots of much needed",160,410);
                g.drawString(" vitamins and nutrients that the body needs to survive.",160,430);
                
                
                
		
		g2d.draw(backButton);
		
		
		
		
	}

}
	
	

